function myFunction() {
    alert("Message sent!");
  }